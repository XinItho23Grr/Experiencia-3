import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApidatosService {
  
  apiUrl='https://jsonplaceholder.typicode.com/users';

  constructor( private httpclient: HttpClient) { }

  //consumimos peticion get de una api publica
  getUsers():Observable<any>{
    return this.httpclient.get<any>(this.apiUrl);
  }


}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApicrudService } from '../services/apicrud.service';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-configuracion-perfil',
  templateUrl: './configuracion-perfil.page.html',
  styleUrls: ['./configuracion-perfil.page.scss'],
})
export class ConfiguracionPerfilPage implements OnInit {

  imageSrc: string | ArrayBuffer | null = null;

  usuarios: any;

  unUsuarios = {
    id: "",
    username: "",
    rut: "",
    nombre: "",
    apellido: "",
    password: "",
    email: "",
    isactive: ""
  };

  constructor(private activated: ActivatedRoute,
              private router: Router,
              private apicrud: ApicrudService,
              private alertcontroller: AlertController) {
              this.activated.queryParams.subscribe(param => {
                this.usuarios = JSON.parse(param['usuarios']);
              })
            }

  ngOnInit() {
    this.imageSrc = localStorage.getItem('photo');
    this.unUsuarios=this.usuarios;
  }

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageSrc = reader.result;  // Imagen Vista
        // Almacenar la imagen en localStorage
        localStorage.setItem('photo', this.imageSrc as string);
      };
      reader.readAsDataURL(file);
    }
  }

  actualizarPerfil() {
    this.router.navigate(['/tabs/tab3'], { state: { imageSrc: this.imageSrc } });
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl, AbstractControl, ValidationErrors } from '@angular/forms';
import { AuthserviceService } from '../services/authservice.service';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { UserNuevo } from 'src/interfaces/users';

@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.page.html',
  styleUrls: ['./crear-usuario.page.scss'],
})
export class CrearUsuarioPage implements OnInit {

  registroForm: FormGroup;

  nuevoUsuario: UserNuevo = {
    username: "",
    rut: "",
    nombre: "",
    apellido: "",
    email: "",
    password: "",
    isactive: false
  }

  userdata: any;

  constructor(
    private authservice: AuthserviceService, 
    private alertcontroller: AlertController,
    private router: Router,
    private fBuilder: FormBuilder
  ) {
    this.registroForm = this.fBuilder.group({
      'username': ['', [Validators.required, Validators.minLength(6)]],
      'rut': ['', [Validators.required, this.validarRut.bind(this)]],
      'nombre': ['', Validators.required],
      'apellido': ['', Validators.required],
      'email': ['', [Validators.required, Validators.email]],
      'password': ['', [Validators.required, Validators.pattern('^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$')]],
      'isactive': [false, Validators.required]
    });
  }

  ngOnInit() {}

  // Validador personalizado para el RUT
  validarRut(control: AbstractControl): ValidationErrors | null {
    const rut = control.value;
    if (!/^\d{7,8}-[0-9Kk]$/.test(rut)) {
      return { invalidRut: true };
    }

    const [body, dv] = rut.split('-');
    const computedDv = this.calcularDigitoVerificador(body);
    if (computedDv.toString().toUpperCase() !== dv.toUpperCase()) {
      return { invalidRut: true };
    }

    return null; // Validación exitosa
  }

  calcularDigitoVerificador(rut: string) {
    let suma = 0;
    let multiplicador = 2;

    for (let i = rut.length - 1; i >= 0; i--) {
      suma += parseInt(rut[i]) * multiplicador;
      multiplicador = multiplicador < 7 ? multiplicador + 1 : 2;
    }

    const resto = suma % 11;
    const dv = 11 - resto;
    return dv === 11 ? '0' : dv === 10 ? 'K' : dv;
  }

  crearUsuario() {
    if (this.registroForm.valid) {
      this.authservice.GetUserByUsername(this.registroForm.value.username).subscribe(resp => {
        this.userdata = resp; 
        if (this.userdata.length > 0) {
          this.registroForm.reset();
          this.errorDuplicidad();
        } else {
          this.nuevoUsuario = { ...this.registroForm.value, isactive: true };
          this.authservice.PostUsuario(this.nuevoUsuario).subscribe();
          this.registroForm.reset();
          this.mostrarMensaje();
          this.router.navigateByUrl('/comienzo');
        }
      });
    }
  }

  async mostrarMensaje() {
    const alerta = await this.alertcontroller.create({
      header: 'Usuario creado',
      message: 'Bienvenid@! ' + this.nuevoUsuario.username,
      buttons: ['OK']
    });
    alerta.present();
  }

  async errorDuplicidad() {
    const alerta = await this.alertcontroller.create({
      header: 'Error..',
      message: 'Usted ' + this.nuevoUsuario.username + ' ya está registrado :D',
      buttons: ['OK']
    });
    alerta.present();
  }

  openUrl(url: string) {
    window.open(url, '_blank');
  }
}

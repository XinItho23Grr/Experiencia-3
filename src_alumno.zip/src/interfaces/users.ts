export interface Users{
    id:number;
    username: string;
    email: string;
    password: string;
    isactive: boolean
}

export interface UserNuevo{ 
    username: string;
    rut: string;
    nombre: string;
    apellido: string;
    email: string;
    password: string;
    isactive: boolean; 
  }
  
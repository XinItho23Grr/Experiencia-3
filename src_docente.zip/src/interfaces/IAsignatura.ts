//peticion,get,put,delete
export interface IAsignaturas{
    id: number;
    nombre: string;
    profesor:string;
    hora: string;
    fecha: Date;
}

//peticion post
export interface Iasignatura{
    nombre: string;
    profesor:string;
    hora: string;
    fecha: Date;
}

export interface IAlumno {
    id: number;
    nombre: string;
    email: string;
    rut: string;
  }


